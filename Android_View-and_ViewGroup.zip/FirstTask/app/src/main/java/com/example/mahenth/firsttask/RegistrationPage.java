package com.example.mahenth.firsttask;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


import java.util.Calendar;

public class RegistrationPage extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5,e9,e10;
    private EditText mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private static final String TAG = "RegistrationPage";
    Spinner spinner;
    RadioGroup radioGroup;
    RadioButton radioButton;
    Switch switch1;

    private Button submit;

    public  void checkButton(View v) {
        int radioid = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioid);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);
        mDisplayDate = (EditText) findViewById(R.id.datepic);
        spinner=(Spinner)findViewById(R.id.spinner);
        e1=(EditText)findViewById(R.id.loginid);
        e2=(EditText)findViewById(R.id.password);
        e3=(EditText)findViewById(R.id.firstname);
        e4=(EditText)findViewById(R.id.lastname);
        e5=(EditText)findViewById(R.id.emailid);
        e9=(EditText)findViewById(R.id.mobnum);
        switch1=(Switch)findViewById(R.id.switc);
           e10=(MultiAutoCompleteTextView)findViewById(R.id.addr);
        submit = (Button)findViewById(R.id.submit_btn);

        e1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(e1.getText().length()<7)
                {
                    e1.setError("Enter the Login ID");
                }
            }
        });
        e2.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(e2.getText().length()<9)
                {
                    e2.setError("Enter the Correct Password");
                }
            }
        });
        e3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(e3.getText().length()<4)
                {
                    e3.setError("Enter the Firstname");
                }
            }
        });

        e4.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(e4.getText().length()<4)
                {
                    e4.setError("Enter Your LastName");
                }
            }
        });

        e5.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(e5.getText().length()<7)
                {
                    e5.setError("Enter the Email-ID");
                }
            }
        });
        mDisplayDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(mDisplayDate.getText().length()<0)
                {
                    mDisplayDate.setError("Choose Your Date-of-Birth");
                }
            }
        });

        e9.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(e9.getText().length() < 11)
                {
                    e9.setError("Enter the MobileNumber");
                }
            }
        });
         spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                e5.requestFocus();
                if(spinner.getSelectedItem().equals(spinner))
                {
                    Toast.makeText(RegistrationPage.this,"Choosed...",Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

                Toast.makeText(RegistrationPage.this,"Choose anyone...",Toast.LENGTH_SHORT).show();
            }
        });

        e10.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(e10.getText().length()<8)
                {
                    e10.setError("Enter Your Address");
                }
            }
        });




        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String login = e1.getText().toString();
                String pass = e2.getText().toString();
                String fn = e3.getText().toString();
                String ln = e4.getText().toString();
                String em = e5.getText().toString();
                String dobb = mDisplayDate.getText().toString();
                String mn = e9.getText().toString();
                String adds = e10.getText().toString();

                if (login.equals("") || pass.equals("") || fn.equals("") || ln.equals("") || em.equals("") || dobb.equals("") || mn.equals("") || adds.equals("")) {

                    Toast.makeText(getApplicationContext(), "Please fill all the Fields ", Toast.LENGTH_SHORT).show();
                }



                else



                    {
                        AlertDialog.Builder builder = new AlertDialog.Builder(RegistrationPage.this);
                        builder.setMessage("Are You Sure?").setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(RegistrationPage.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                            }
                        }).setNegativeButton("CANCEL", null);
                        AlertDialog alert = builder.create();

                        alert.show();


                }

            }
        });



        String name= null;
        if(spinner != null && spinner.getSelectedItem() !=null ) {
            name = (String)spinner.getSelectedItem();
        } else {

            Toast.makeText(getApplicationContext(), "Fields are Empty", Toast.LENGTH_SHORT).show();
        }








        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(RegistrationPage.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                Log.d(TAG,"onDateSet:mm/dd/yyy" + month + "/" + dayOfMonth + "/" + year);

                String date = month + "/" + dayOfMonth + "/" + year;
                mDisplayDate.setText(date);
            }
        };


    }
}
