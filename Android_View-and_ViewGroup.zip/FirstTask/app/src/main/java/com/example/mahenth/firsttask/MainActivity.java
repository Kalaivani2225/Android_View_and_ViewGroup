package com.example.mahenth.firsttask;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.lang.String;

import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.Source;
import javax.xml.validation.Validator;

public class MainActivity extends AppCompatActivity {
	EditText emailEditText, passEditText;
	Button b1, b2;
	Validator validate;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		emailEditText = (EditText) findViewById(R.id.username);
		passEditText = (EditText) findViewById(R.id.password);
		b1 = (Button) findViewById(R.id.login_btn);
		b2 = (Button) findViewById(R.id.signup_btn);


		emailEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (emailEditText.getText().length() < 8) {
					emailEditText.setError("Enter the valid Username");
				}
			}
		});

		passEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (passEditText.getText().length() < 8) {
					passEditText.setError("Password must have 8 characters");
				}
			}
		});


		b2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, RegistrationPage.class);
				startActivity(i);
			}
		});


		b1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!validateEmail(emailEditText.getText().toString())) {
					emailEditText.setError("Invalid Email...");
					emailEditText.requestFocus();
				} else if (!validatePassword(emailEditText.getText().toString())) {
					passEditText.setError("Invalid Password");
					passEditText.requestFocus();
				} else {
					Toast.makeText(MainActivity.this, "Input Validation Success....", Toast.LENGTH_SHORT).show();
				}
			}

			// String s1 = emailEditText.getText().toString();
			//tring s2 = passEditText.getText().toString();


			// String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";


			// if (s1.equals("") || s2.equals("")) {
			//	 Toast.makeText(getApplicationContext(), "Please fill all the Fields ", Toast.LENGTH_SHORT).show();
			//} else {
			// AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
			//		 builder.setMessage("Are You Sure?").setPositiveButton("OK", new DialogInterface.OnClickListener() {
			//			 @Override
			//			 public void onClick(DialogInterface dialog, int which) {
			//				 Toast.makeText(MainActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
			// }
			//}).setNegativeButton("CANCEL", null);
			//AlertDialog alert = builder.create();

			//alert.show();


		});
	}
		 protected boolean validatePassword(String password) {
			 if (password != null && password.length() < 8) {
				 return true;
			 } else {
				 return false;
			 }
		 }
	protected boolean validateEmail(String email)
	{
	String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

	Pattern pattern=Pattern.compile(emailPattern);
	Matcher matcher=pattern.matcher(email);
			return matcher.matches();
	}

}











	